package com.sj.service;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sj.bean.Student;
import com.sj.model.StudentDAO;

@Service
public class StudentServiceImpl implements StudentService {

	private StudentDAO studentDAO;

	public void setStudentDAO(StudentDAO studentDAO) {
		System.out.println(getClass() + " studentDAO " + studentDAO);
		this.studentDAO = studentDAO;
	}

	@Transactional
	public List<Student> getStudentList() {

		return studentDAO.getStudentList();
	}

	@Transactional
	public void storeStudent(Student student) {
		System.out.println(getClass());
		this.studentDAO.storeStudent(student);

	}

}
