package com.pz.SpringMail;

public interface SendMail {
	public String sendMail(String to);
}
